package ch.epfl.javions.adsb;

import ch.epfl.javions.Bits;
import ch.epfl.javions.Preconditions;
import ch.epfl.javions.Units;
import ch.epfl.javions.aircraft.IcaoAddress;

import java.util.Objects;

public record AirbornePositionMessage(long timeStampNs, IcaoAddress icaoAddress, double altitude, int parity,
                                      double x, double y) implements Message {

    public AirbornePositionMessage {
        Objects.requireNonNull(icaoAddress);
        Preconditions.checkArgument((timeStampNs >= 0) && (parity == 1 || parity == 0) && (x >= 0)
                && (x < 1) && (y >= 0) && (y < 1));
    }

    public static AirbornePositionMessage of(RawMessage rawMessage) {

        long timeStampNs = rawMessage.timeStampNs();
        IcaoAddress icaoAddress = rawMessage.icaoAddress();
        double altitude = 0;
        int ALT = Bits.extractUInt(rawMessage.payload(), 36,12);
        int FORMAT = Bits.extractUInt(rawMessage.payload(),34,1);
        double LON_CPR = Bits.extractUInt(rawMessage.payload(),0,17)*Math.scalb(1d,-17);
        double LAT_CPR = Bits.extractUInt(rawMessage.payload(),17,17)*Math.scalb(1d,-17);
        int Q = Bits.extractUInt(ALT, 4,1);

        if (Q == 1){

            int bits1 = Bits.extractUInt(ALT, 5,7);
            int bits2 = Bits.extractUInt(ALT, 0,4);

            ALT = (bits1 << 4) | bits2;
            altitude = Units.convertFrom(-1000 + (ALT * 25), Units.Length.FOOT);
        }

        if (Q == 0){
            int lsbGroupe=Bits.extractUInt(untangler(ALT),0,3);
            lsbGroupe=greyTrasslator(lsbGroupe);
            int msbGroupe=Bits.extractUInt(untangler(ALT),3,9);
            msbGroupe=greyTrasslator(msbGroupe);

            if (lsbGroupe == 0 || lsbGroupe == 5 || lsbGroupe == 6) return null;
            if(lsbGroupe == 7) lsbGroupe = 5;
            if (msbGroupe %2 != 0) lsbGroupe = 6 - lsbGroupe;

            altitude = Units.convertFrom(-1300+(lsbGroupe*100)+(msbGroupe*500), Units.Length.FOOT);
        }

        return new AirbornePositionMessage(timeStampNs, icaoAddress, altitude, FORMAT, LON_CPR, LAT_CPR);
    }

    private static byte[] intToBitArray(int num) {
        byte[] bits = new byte[12]; // Un int a 32 bits
        for (int i = 0; i < 12; i++) {
            bits[i] = (byte) ((num >> i) & 1); // Extraction du i-ème bit de num
        }
        return bits;
    }

    private static int byteArrayToLSBInt(byte[] bytes) {
        int result = 0;
        for (int i = 0; i < 12; i++) {
            result |= bytes[i];
            result<<=1;// Décalage de 8 bits à chaque itération
        }
        return result;
    }

    private static int untangler(int ALT){
        byte [] altArray=intToBitArray(ALT);
        byte[] temp=new byte[12];
        temp[0]=altArray[4];
        temp[1]=altArray[2];
        temp[2]=altArray[0];
        temp[3]=altArray[10];
        temp[4]=altArray[8];
        temp[5]=altArray[6];
        temp[6]=altArray[5];
        temp[7]=altArray[3];
        temp[8]=altArray[1];
        temp[9]=altArray[11];
        temp[10]=altArray[9];
        temp[11]=altArray[7];
        return byteArrayToLSBInt(temp);
    }

    private static int greyTrasslator(int num){
        for(int i=0; i< Integer.SIZE;i++) num^=(num>>i);
        return num;
    }
}