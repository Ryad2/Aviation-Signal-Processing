package ch.epfl.javions;

/*public class Bits {

    public static int extractUInt (long value, int start, int size)
    {
        return 0;
    }

    public static boolean testBit (long value, int index)
    {
        if (index==1) return true;
        if ((value<=0) || (value>Long.SIZE)) throw new IndexOutOfBoundsException();
        else throw new IndexOutOfBoundsException();
    }
}
*/

import java.util.Objects;

public final class Bits {

    private Bits() {
        throw new AssertionError("Classe non instanciable");
    }

    public static int extractUInt(long value, int start, int size) {

        if (size <= 0 || size >= Integer.SIZE) {
            throw new IllegalArgumentException("La taille doit être strictement supérieure à 0 et strictement inférieure à 32");
        }
        int slot = start + size;
        if (0 > slot || slot > Long.SIZE) {
            throw new IndexOutOfBoundsException("La plage décrite par start et size n'est pas totalement comprise entre 0 (inclus) et 64 (exclu)");
        }
        Objects.checkFromIndexSize(start, size, Long.SIZE);
        long mask = (1L << size) - 1L;
        return (int) ((value >>> start) & mask);
    }

    public static boolean testBit(long value, int index) {
        Objects.checkIndex(index, Long.SIZE);
        long mask = 1L << index;
        return (value & mask) != 0L;
    }
}
