package ch.epfl.javions;

import java.util.Arrays;
import java.util.HexFormat;

public final class ByteString {


    private final byte[] chaine;

    private final static HexFormat vf = HexFormat.of().withUpperCase();

    public ByteString(byte[] bytes) {
        this.chaine = Arrays.copyOf(bytes, bytes.length);
    }

    public static boolean isHexadecimal(char c) {// ASK ASSISTANT IF THIS METHODE ALREADY EXISTE IN JAVA !!!!!!
        return Character.isDigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }


    public static ByteString ofHexadecimalString(String hexString) {
        // verify that the length is even
        if (hexString.length() % 2 != 0) {
            throw new NumberFormatException("The length of the chaine have to be even");
        }

        // testing if all characters are hexadecimal
        for (int i = 0; i < hexString.length(); i ++) {
            if(!isHexadecimal(hexString.charAt(i))){
                throw new NumberFormatException("the chaine contain a character which is not hexadecimal ");
                }
        }

        //transform a string to a byteString
        HexFormat result = HexFormat.of().withUpperCase();
        return new ByteString(result.parseHex(hexString));
    }

    public int size() {
        return chaine.length;
    }

    public int byteAt(int index) {
        if (index < 0 || index >= chaine.length) {
            throw new IndexOutOfBoundsException("Index invalide : " + index);
        }

        // We use a conversion to interpret the byte as unsigned
        return chaine[index] & 0xff;
    }

    public long bytesInRange(int fromIndex, int toIndex) {
        // Check that the range is valid
        if (fromIndex < 0 || toIndex > chaine.length || toIndex - fromIndex > Long.BYTES) {
            throw new IllegalArgumentException("Plage invalide");
        }

        // Build along from bytes in given range
        long result = 0;
        for (int i = fromIndex; i < toIndex; i++) {
            result = (result << 8) + Byte.toUnsignedInt(chaine[i]);
        }
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ByteString)) {
            return false;
        }
        ByteString other = (ByteString) obj;
        if (this.chaine.length != other.chaine.length) {
            return false;
        }
        for (int i = 0; i < this.chaine.length; i++) {
            if (this.chaine[i] != other.chaine[i]) {
                return false;
            }
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(this.chaine);
    }

    @Override
    public String toString() {
        return vf.formatHex(chaine);
    }
}