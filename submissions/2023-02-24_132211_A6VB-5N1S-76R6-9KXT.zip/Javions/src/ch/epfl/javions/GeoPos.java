package ch.epfl.javions;

public record GeoPos (int longitudeT32, int latitudeT32) {

    public GeoPos {
        if (!isValidLatitudeT32(latitudeT32)) throw new IllegalArgumentException();
        // Should maybe be taken off
        if (!isValidLongitudeT32(latitudeT32)) throw new IllegalArgumentException();
    }

    public static boolean isValidLatitudeT32(int latitudeT32) {
        return (latitudeT32 >= Units.Angle.MINT32) && (latitudeT32 <= Units.Angle.MAXT32);
    }

    public static boolean isValidLongitudeT32(int longitudeT32) {
        return(longitudeT32 >= Units.Angle.MINT32) && (longitudeT32 <= Units.Angle.MAXT32);
    }

    public double longitude () {
        //To show to the assistant
        //probably a hugge shit
        return Units.convert(longitudeT32, Units.Angle.T32, Units.Angle.RADIAN);
    }

    public double latitude () {
        //To show to the assistant
        //probably a bigger shit
        return Units.convert(latitudeT32, Units.Angle.T32, Units.Angle.RADIAN);
    }

    @Override
    public String toString () {
        return "("+ Units.convert(longitudeT32, Units.Angle.T32, Units.Angle.DEGREE) + "°, " +
                Units.convert(latitudeT32, Units.Angle.T32, Units.Angle.DEGREE)+"°)";
    }
}
