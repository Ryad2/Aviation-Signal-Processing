package ch.epfl.javions;

public final class Preconditions {

    private Preconditions() {
        throw new AssertionError("Classe non instanciable");
    }

    public static void checkArgument (boolean shouldBeTrue) {
        if (!shouldBeTrue)  throw new IllegalArgumentException();
    }


}

