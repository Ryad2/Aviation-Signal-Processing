package ch.epfl.javions.adsb;

import ch.epfl.javions.GeoPos;
import ch.epfl.javions.Preconditions;
import ch.epfl.javions.Units;

import static ch.epfl.javions.Units.convert;
import static ch.epfl.javions.Units.convertFrom;

public class CprDecoder {
    //DEMANDER AU ASSISTANTS SI ON DOIT RECEVOIR LES X ET Y NORMALISE ou non (divité par 2^17)
    private static int longitudeZoneNumberEven;
    private static int longitudeZoneNumberOdd;
    private static double positionLatitudeEven;
    private static final double LATITUDE_ZONE_NUMBER_EVEN = 60;
    private static final double LATITUDE_LENGTH_EVEN = 1d / LATITUDE_ZONE_NUMBER_EVEN;
    private static final double LATITUDE_ZONE_NUMBER_ODD = 59;

    public static GeoPos decodePosition(double x0, double y0, double x1, double y1, int mostRecent) {

        Preconditions.checkArgument(mostRecent == 1 || mostRecent == 0);


        positionLatitudeEven = (LATITUDE_LENGTH_EVEN) * (latitudeZoneFonder(y0, y1
                        ,LATITUDE_ZONE_NUMBER_EVEN) + y0);//correct

        double positionLatitudeOdd = (1.0 / LATITUDE_ZONE_NUMBER_ODD) * (latitudeZoneFonder(y0, y1
                , LATITUDE_ZONE_NUMBER_ODD) + y1);//correct

        longitudeZoneNumberEven = (int) Math.floor((2 * Math.PI) / calculatorArccos());//correct
        longitudeZoneNumberOdd = longitudeZoneNumberEven - 1;//correct

        double positionLongitudeEven = getLongitudeEven(x0, x1, longitudeZoneNumberEven);

        double positionLongitudeOdd = getLongitudeOdd(x0, x1, longitudeZoneNumberEven);

        double positionLatitudeOddDegree = convert(positionLatitudeOdd, Units.Angle.TURN, Units.Angle.DEGREE);
        double positionLatitudeEvenDegree = convert(positionLatitudeEven, Units.Angle.TURN, Units.Angle.DEGREE);


        if (positionLatitudeOddDegree > 90 || positionLatitudeOddDegree < 0 || positionLatitudeEvenDegree > 90
                || positionLatitudeEvenDegree < 0) {
            return null;
        }

        return new GeoPos(
            (int)Math.rint(convert(mostRecent(positionLongitudeEven, positionLongitudeOdd,mostRecent),
                    Units.Angle.TURN, Units.Angle.T32)),
            (int) Math.rint(convert(mostRecent(positionLatitudeEven, positionLatitudeOdd,mostRecent),
                    Units.Angle.TURN, Units.Angle.T32))
        );
    }



    private static double latitudeZoneFonder(double y0, double y1, double latitudeZoneNumber) {
        double latitudeZone = Math.rint((y0 * LATITUDE_ZONE_NUMBER_ODD) - (y1 * LATITUDE_ZONE_NUMBER_EVEN));
        if (latitudeZone < 0) return latitudeZone + latitudeZoneNumber; 
        else return latitudeZone;
    }



    private static double longitudeZoneFonder(double x0, double x1, double longitudeZoneNumber) {

            double latitudeZone = Math.rint((x0 * longitudeZoneNumberOdd) - (x1 * longitudeZoneNumberEven));
            if (latitudeZone < 0) {
                return latitudeZone + longitudeZoneNumber;
            }
            else return latitudeZone;
    }



    private static double getLongitudeEven (double x0, double x1, int longitudeZoneNumberEven){
        if (longitudeZoneNumberEven == 1) {
            return x0;
        }
        return ((1d/longitudeZoneNumberEven) * (longitudeZoneFonder(x0, x1, longitudeZoneNumberEven) + x0));
    }



    private static double getLongitudeOdd (double x0, double x1, int longitudeZoneNumberEven){
        if (longitudeZoneNumberOdd == 1) {
            return x0;
        }
        return ((1d/longitudeZoneNumberOdd) * (longitudeZoneFonder(x0, x1, longitudeZoneNumberOdd) + x0));
    }



    private static double calculatorArccos() {
        double angle = Math.cos(convertFrom(positionLatitudeEven, Units.Angle.TURN));

        double a = Math.acos(1 - (1 - Math.cos((2 * Math.PI * LATITUDE_LENGTH_EVEN))) / (angle*angle));

        if (Double.isNaN(a)) {
            return 1;
        }
        return a;
    }



    private static double mostRecent(double even, double odd, int mostResent) {
        if (mostResent == 0) {
            return even;
        } else {
            return odd;
        }
    }
}