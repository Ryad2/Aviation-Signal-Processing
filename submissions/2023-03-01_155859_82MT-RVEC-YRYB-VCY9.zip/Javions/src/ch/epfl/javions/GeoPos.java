package ch.epfl.javions;

/**
 * Représente des coordonnées géographiques : un couple longitude/latitude. Ces données sont exprimées
 * en t32 et stockées sous la forme d'entiers de 32 bits (type int)
 * @author Ethan Boren (361582)
 * @author Ryad Aouak (315258)
 */

/**
 * Lance une exception si la latitude et la longitude n'est pas exprimée en T32
 * @param longitudeT32 la longitude exprimée en T32
 * @param latitudeT32 la latitude exprimée en T32
 * @throws IllegalArgumentException
 * @throws IllegalArgumentException
 */

public record GeoPos (int longitudeT32, int latitudeT32) {

    public GeoPos {
        if (!isValidLatitudeT32(latitudeT32)) throw new IllegalArgumentException();
        // Should maybe be taken off
        if (!isValidLongitudeT32(latitudeT32)) throw new IllegalArgumentException();
    }

    /**
     * Permet de vérifier si la latitude est valide
     * @param latitudeT32 paramètre donné
     * @return vrai ssi la valeur passée, interprétée comme une latitude exprimée en t32, est valide : comprise
     * entre -2^30 et 2^30 inclus
     */

    public static boolean isValidLatitudeT32(int latitudeT32) {
        return (latitudeT32 >= Units.Angle.MINT32) && (latitudeT32 <= Units.Angle.MAXT32);
    }

    /**
     * Permet de vérifier si la longitude est valide
     * @param longitudeT32 paramètre donné
     * @return vrai ssi la valeur passée, interprétée comme une longitude exprimée en t32, est valide
     */

    public static boolean isValidLongitudeT32(int longitudeT32) {
        return(longitudeT32 >= Units.Angle.MINT32) && (longitudeT32 <= Units.Angle.MAXT32);
    }

    /**
     * calcul la longitude
     * @return la longitude en radian
     */
    public double longitude () {
        //To show to the assistant
        //probably a hugge shit
        return Units.convert(longitudeT32, Units.Angle.T32, Units.Angle.RADIAN);
    }

    /**
     * calcul la latitude
     * @return la latitude en radian
     */
    public double latitude () {
        //To show to the assistant
        //probably a bigger shit
        return Units.convert(latitudeT32, Units.Angle.T32, Units.Angle.RADIAN);
    }

    /**
     * Convertir des données textuellement
     * @return une représentation textuelle de la position dans laquelle la longitude et la latitude sont données
     * dans cet ordre, en degrés
     */
    @Override
    public String toString () {
        return "("+ Units.convert(longitudeT32, Units.Angle.T32, Units.Angle.DEGREE) + "°, " +
                Units.convert(latitudeT32, Units.Angle.T32, Units.Angle.DEGREE)+"°)";
    }
}
