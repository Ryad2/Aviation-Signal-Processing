package ch.epfl.javions.aircraft;

import java.io.*;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class AircraftDatabase {
    private final String fileName;

    public AircraftDatabase(String fileName) {
        if (fileName == null) {
            throw new NullPointerException("Le nom du fichier ne peut pas être nul");
        }
        this.fileName = fileName;
    }

    /**
     *
     * @param address prend ICO adress d'un aeronerf
     * @return AircraftData si l'adress est dans le fichier et retourne
     * @throws IOException
     */
    public AircraftData get(IcaoAddress address) throws IOException {

        String nomFichier = getClass().getResource(fileName).getFile();
        nomFichier = URLDecoder.decode(nomFichier, "utf8");


        String crc = address.string();
        String numero = crc.substring(crc.length()-2);

        try (ZipFile fichierZipe = new ZipFile(nomFichier);
             InputStream s = fichierZipe.getInputStream(fichierZipe.getEntry(numero+".csv"));
             Reader r = new InputStreamReader(s, StandardCharsets.UTF_8);
             BufferedReader b = new BufferedReader(r))

        {
            String[] columns = new String[5];
            String ligne = "";
             while ((ligne = b.readLine()) != null) {
                if (ligne.startsWith(address.string())) {
                    columns = ligne.split(",");

                    return new AircraftData(new AircraftRegistration(columns[1]),
                            new AircraftTypeDesignator(columns[2]),
                            columns[3],
                            new AircraftDescription(columns[4]),
                            WakeTurbulenceCategory.of(columns[5]));

                }
                if (ligne.compareTo(address.toString()) > 0) {
                    // Stop searching when we have passed the target address
                    break;
                }
            }

        }
        return null;
    }
}