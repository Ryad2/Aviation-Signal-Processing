package ch.epfl.javions.aircraft;

import java.util.regex.Pattern;

/**
 * Représente l'immatriculation d'un avion
 * @author Ethan Boren (361582)
 * @author Ryad Aouak (315258)
 */

public record AircraftRegistration(String string) {

    /**
     * Lève une exception si le string n'est pas une immatriculation OACI valide
     * @param string représente la chaîne contenant la représentation textuelle de l'adresse d'une immatriculation
     * @throws IllegalArgumentException
     */

    private static Pattern pattern = Pattern.compile("[A-Z0-9 .?/_+-]+");
    public AircraftRegistration {                                   // SHOULD BE VALID BY AN ASSISTANT!!!!
        if (!pattern.matcher(string).matches()){
            throw new IllegalArgumentException("Immatriculation n'est pas valide !!!");
        }
    }
}

