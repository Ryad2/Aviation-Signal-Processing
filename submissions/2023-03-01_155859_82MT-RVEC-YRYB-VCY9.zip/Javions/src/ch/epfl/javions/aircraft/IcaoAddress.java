package ch.epfl.javions.aircraft;
import java.util.regex.Pattern;

/**
 * Représente une adresse OACI
 * @author Ethan Boren (361582)
 * @author Ryad Aouak (315258)
 */

public record IcaoAddress(String string) {

    /**
     * Lève une exception si le string n'est pas une adresse OACI valide
     * @param string représente la chaîne contenant la représentation textuelle de l'adresse OACI
     * @throws IllegalArgumentException quand IC
     * @throws IllegalArgumentException
     */

    private static Pattern pattern = Pattern.compile("[0-9A-F]{6}");
    public IcaoAddress {                                   // SHOULD BE VALID BY AN ASSISTANT!!!!
        if (!pattern.matcher(string).matches()){
            throw new IllegalArgumentException("Adresse OACI n'est pas valide !!!");
        }
    }
}

