package ch.epfl.javions.adsb;

import ch.epfl.javions.GeoPos;
import ch.epfl.javions.Preconditions;
import ch.epfl.javions.Units;

import static ch.epfl.javions.Units.convert;
import static ch.epfl.javions.Units.convertFrom;

public class CprDecoder {
    //DEMANDER AU ASSISTANTS SI ON DOIT RECEVOIR LES X ET Y NORMALISE ou non (divité par 2^17)
   // private static int longitudeZoneNumberEven;
    //private static int longitudeZoneNumberOdd;
   // private static double positionLatitudeEven;
    private CprDecoder(){}
    private static final double LATITUDE_ZONE_NUMBER_EVEN = 60;
    private static final double LATITUDE_LENGTH_EVEN = 1d / LATITUDE_ZONE_NUMBER_EVEN;
    private static final double LATITUDE_ZONE_NUMBER_ODD = 59;

    public static GeoPos decodePosition(double x0, double y0, double x1, double y1, int mostRecent) {

        Preconditions.checkArgument(mostRecent == 1 || mostRecent == 0);


        double positionLatitudeEven = (LATITUDE_LENGTH_EVEN) * (latitudeZoneFonder(y0, y1
                        ,LATITUDE_ZONE_NUMBER_EVEN) + y0);//correct

        if (positionLatitudeEven >= 0.5) positionLatitudeEven -= 1;


        double positionLatitudeOdd = (1d / LATITUDE_ZONE_NUMBER_ODD) * (latitudeZoneFonder(y0, y1
                , LATITUDE_ZONE_NUMBER_ODD) + y1);//correct

        if (positionLatitudeOdd >= 0.5)  positionLatitudeOdd -= 1;



        double test = calculatorArccos(positionLatitudeEven);
        int longitudeZoneNumberEven = 1;
        if (!Double.isNaN(test))  longitudeZoneNumberEven = (int) Math.floor((2 * Math.PI) / test);


        double test1 = calculatorArccos(positionLatitudeOdd);
        int longitudeZoneNumberTestOdd = 1;
        if (!Double.isNaN(test1))  longitudeZoneNumberTestOdd = (int) Math.floor((2 * Math.PI) / test);

        if(longitudeZoneNumberEven!=longitudeZoneNumberTestOdd) return null;


        int longitudeZoneNumberOdd = longitudeZoneNumberEven - 1;//correct

        double positionLongitudeEven = getLongitudeEven(x0, x1, longitudeZoneNumberEven, longitudeZoneNumberOdd);
        double positionLongitudeOdd = getLongitudeOdd(x0, x1, longitudeZoneNumberEven, longitudeZoneNumberOdd);


        if (positionLongitudeEven >= 0.5) positionLongitudeEven -= 1;
        if (positionLongitudeOdd >= 0.5)  positionLongitudeOdd -= 1;


        int positionLatitudeOddT32 = (int)Math.rint(convert(positionLatitudeOdd, Units.Angle.TURN, Units.Angle.T32));
        int positionLatitudeEvenT32 = (int) Math.rint(convert(positionLatitudeEven, Units.Angle.TURN, Units.Angle.T32));



        if (!(GeoPos.isValidLatitudeT32(positionLatitudeOddT32) && GeoPos.isValidLatitudeT32(positionLatitudeEvenT32)) ){
            return null;
        }

        return new GeoPos(
            (int)Math.rint(convert(mostRecent(positionLongitudeEven, positionLongitudeOdd,mostRecent),
                    Units.Angle.TURN, Units.Angle.T32)),
            (int) mostRecent(positionLatitudeEvenT32, positionLatitudeOddT32,mostRecent));
    }



    private static double latitudeZoneFonder(double y0, double y1, double latitudeZoneNumber) {
        double latitudeZone = Math.rint((y0 * LATITUDE_ZONE_NUMBER_ODD) - (y1 * LATITUDE_ZONE_NUMBER_EVEN));
        if (latitudeZone < 0) return latitudeZone + latitudeZoneNumber; 
        else return latitudeZone;
    }

    private static int longitudeZoneFinder(double x0, double x1, int longitudeZoneNumberEven, int longitudeZoneNumberOdd) {

           return (int) Math.rint( (x0 * longitudeZoneNumberOdd) - (x1 * longitudeZoneNumberEven) ) ;

    }

    private static double getLongitudeEven (double x0, double x1, int longitudeZoneNumberEven, int longitudeZoneNumberOdd){

        if (longitudeZoneNumberEven == 1)  return x0;


        int zLamda= longitudeZoneFinder(x0, x1, longitudeZoneNumberEven, longitudeZoneNumberOdd);
        if(zLamda<0) zLamda+=longitudeZoneNumberEven;

        return ((1d/longitudeZoneNumberEven) * (zLamda + x0) );
    }


    private static double getLongitudeOdd (double x0, double x1, int longitudeZoneNumberEven , int longitudeZoneNumberOdd){

        if (longitudeZoneNumberOdd == 1) return x1;

        int zLamda= longitudeZoneFinder(x0, x1,longitudeZoneNumberEven, longitudeZoneNumberOdd);
        if(zLamda<0) zLamda+=longitudeZoneNumberOdd;

        return ((1d/longitudeZoneNumberOdd) * (zLamda+ x1));
    }


    private static double calculatorArccos(double positionLatitudeEven) {
        double angle = Math.cos(convertFrom(positionLatitudeEven, Units.Angle.TURN));

        return Math.acos(1 - (1 - Math.cos((2 * Math.PI * LATITUDE_LENGTH_EVEN))) / (angle*angle));
    }


    private static double mostRecent(double even, double odd, int mostResent) {

        if (mostResent == 0)  return even;
         else return odd;

    }
}