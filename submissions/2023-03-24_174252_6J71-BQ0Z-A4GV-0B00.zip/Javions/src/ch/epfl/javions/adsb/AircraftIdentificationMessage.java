package ch.epfl.javions.adsb;

import ch.epfl.javions.Bits;
import ch.epfl.javions.Preconditions;
import ch.epfl.javions.aircraft.IcaoAddress;

import java.util.Objects;


public record  AircraftIdentificationMessage(long timeStampNs, IcaoAddress icaoAddress,
                                            int category, CallSign callSign) implements Message {

    public AircraftIdentificationMessage {
        Objects.requireNonNull(icaoAddress);
        Objects.requireNonNull(callSign);
        Preconditions.checkArgument(timeStampNs >= 0);
    }


    public static AircraftIdentificationMessage of(RawMessage rawMessage){
        String indicator="";
        int ca= Bits.extractUInt(rawMessage.payload(),48,3);
        int category =( (14- rawMessage.typeCode())<<4 ) | ca;

        for(int i=0; i<8;i++){
            indicator+= character(Bits.extractUInt(rawMessage.payload(), 42 - i * 6, 6));
        }
    return new AircraftIdentificationMessage(rawMessage.timeStampNs(), rawMessage.icaoAddress(),category,
            new CallSign(indicator.trim()));
    }

    private static char character(int val){
        char output;
        if (val == 32) {
            output= ' ';
        } else if (val >= 48 && val <= 57) {
            output= (char) val;
        } else if (val >= 1 && val <= 26) {
            output = (char) (val + 64);
        } else {
            output = ' ';
        }
        return output;
    }
}