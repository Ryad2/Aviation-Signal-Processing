package ch.epfl.javions;

public final class Crc24 {
    public static final int GENERATOR=0xFFF409;
    private final int[] table;
    private static final int CRC_BITS = 24;


    public Crc24(int generator) {

        this.table = buildTable(generator);
    }

    public int crc(byte[] message) {
        var crc = 0;
        for(var el : message){
            crc= ( (crc<<Byte.SIZE) | Byte.toUnsignedInt(el)) ^
                    table[Bits.extractUInt(crc,CRC_BITS-Byte.SIZE,Byte.SIZE ) ] ;
        }

        for (int i = 0; i < 3; i++) {
            crc=(crc<<Byte.SIZE) ^ table[Bits.extractUInt(crc,CRC_BITS-Byte.SIZE,Byte.SIZE)] ;
        }

        return Bits.extractUInt(crc, 0,CRC_BITS);
        //return crc_bitwise(GENERATOR, message);
    }

    private static int[] buildTable(int generator) {
        int[] table = new int[1 << Byte.SIZE];

        for (int i = 0; i < table.length; i++) {
            byte [] bit_w= new byte[]{(byte)i};
            table[i]=crc_bitwise(generator, bit_w);
        }
        return table;
    }

    private static int crc_bitwise(int generateur, byte[] message) {

        int[] tab = new int[]{0,generateur};
        var crc = 0;

        for (byte b : message) {
            for (int j = Byte.SIZE-1; j>= 0; j--) {
                crc = ( (crc<<1) | Bits.extractUInt(b, j,1) ) ^ tab[Bits.extractUInt(crc,CRC_BITS-1,1)];
            }
        }

        for (int i = 0; i < CRC_BITS; i++) {
            crc=(crc<<1) ^ tab[Bits.extractUInt(crc,CRC_BITS-1,1)] ;
        }

        return Bits.extractUInt(crc, 0,CRC_BITS);
    }
}